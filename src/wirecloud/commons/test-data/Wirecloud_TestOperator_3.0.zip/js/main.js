(function () {

    "use strict";

    class TestOperatorA {
        constructor(MashupPlatform, _) {
            this.MashupPlatform = MashupPlatform;
            
            MashupPlatform.wiring.registerCallback('input', (data) => {
                if (data === 'typeerror') {
                    throw new MashupPlatform.wiring.EndpointTypeError('invalid data format');
                } else if (data === 'valueerror') {
                    throw new MashupPlatform.wiring.EndpointValueError('invalid value');
                } else if (data === 'dashboard_management_test') {
                    try {
                        this.dashboard_management_test();
                    } catch (e) {
                        MashupPlatform.wiring.pushEvent('output', 'Failure!!');
                    }
                    return;
                } else if (MashupPlatform.prefs.get('exception_on_event')) {
                    throw new Error();
                }
                MashupPlatform.wiring.pushEvent('output', MashupPlatform.prefs.get('prefix') + data);
            });
        
            MashupPlatform.prefs.registerCallback((new_values) => {
                if (new_values.test_logging === true) {
                    MashupPlatform.operator.log('error message');
                    MashupPlatform.operator.log('error message2', MashupPlatform.log.ERROR);
                    MashupPlatform.operator.log('warn message', MashupPlatform.log.WARN);
                    MashupPlatform.operator.log('info message', MashupPlatform.log.INFO);
                }
                MashupPlatform.wiring.pushEvent('output', 'preferences changed: ' + Object.keys(new_values));
            });
        
            if (MashupPlatform.prefs.get('register_status_callback')) {
                MashupPlatform.wiring.registerStatusCallback(function () {
                    MashupPlatform.wiring.pushEvent('output', 'wiring modified');
                });
            }
        }

        dashboard_management_test() {
            // Error reporting
            try {
                this.MashupPlatform.operator.outputs.output.connect(null);
                throw Exception();
            } catch (e) {
                if (!(e instanceof TypeError)) {
                    throw e;
                }
            }
    
            try {
                this.MashupPlatform.operator.outputs.output.connect(this.MashupPlatform.operator.inputs.input);
                throw Exception();
            } catch (e) {
                if (!(e instanceof TypeError)) {
                    throw e;
                }
            }
    
            try {
                this.MashupPlatform.mashup.addWidget(null);
                throw Exception();
            } catch (e) {
                if (!(e instanceof TypeError)) {
                    throw e;
                }
            }
    
            try {
                this.MashupPlatform.mashup.addOperator(null);
                throw Exception();
            } catch (e) {
                if (!(e instanceof TypeError)) {
                    throw e;
                }
            }
    
            // Flow 1: new widget directly connected to this operator
            var widget1 = this.MashupPlatform.mashup.addWidget('Wirecloud/api-test/0.9');
            this.MashupPlatform.operator.outputs.output.connect(widget1.inputs.inputendpoint);
    
            // Flow 2: new widget connected through a new operator
            var widget2 = this.MashupPlatform.mashup.addWidget('Wirecloud/api-test/0.9', {top: "50%", left: "50%"});
            var operator = this.MashupPlatform.mashup.addOperator('Wirecloud/TestOperator/1.0');
            this.MashupPlatform.operator.outputs.output.connect(operator.inputs.input);
            operator.outputs.output.connect(widget2.inputs.inputendpoint);
    
            this.MashupPlatform.operator.outputs.output.pushEvent('Success!!');
        }
    }

    window["TestOperatorA"] = TestOperatorA;

})();
